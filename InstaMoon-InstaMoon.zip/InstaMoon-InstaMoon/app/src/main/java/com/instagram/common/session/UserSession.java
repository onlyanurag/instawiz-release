package com.instagram.common.session;

public class UserSession {
}
