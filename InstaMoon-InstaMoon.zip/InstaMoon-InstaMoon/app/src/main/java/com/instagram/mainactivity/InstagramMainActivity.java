package com.instagram.mainactivity;

import androidx.appcompat.app.AppCompatActivity;

import com.instagram.common.session.UserSession;

import X._2up;

public class InstagramMainActivity extends AppCompatActivity {

    public UserSession A05;

//    public final _2up BIK() {
//        return null;
//    }

}
