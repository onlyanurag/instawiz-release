package com.instagram.debug.devoptions.api;

import android.content.Context;

import androidx.fragment.app.FragmentActivity;

import com.instagram.common.session.UserSession;

import X._2up;

public class DeveloperOptionsLauncher {
    public static final DeveloperOptionsLauncher INSTANCE = new DeveloperOptionsLauncher();

    public final void loadAndLaunchDeveloperOptions(Context context, FragmentActivity fragmentActivity, UserSession userSession){}

//    public final void loadAndLaunchDeveloperOptions(Context context, _2up _2up, FragmentActivity fragmentActivity, UserSession userSession) {
//
//    }

}
