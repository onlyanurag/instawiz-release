package X;

public class _2up {
}
