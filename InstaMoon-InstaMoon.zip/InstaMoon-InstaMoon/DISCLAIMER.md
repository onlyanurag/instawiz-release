# Disclaimer

This project is intended for **educational purposes only**. 

The use of this code to interact with or modify third-party applications such as Instagram may:
- Violate their **terms of service**.
- Be against applicable **laws** in your jurisdiction.

The author of this project does not endorse or condone any misuse of this code. The user assumes full responsibility for any actions performed with this code.

Use this project at your own risk.
